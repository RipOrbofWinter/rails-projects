class GraphsController < ApplicationController

	# require_relative "Classes/Calculator.rb"

  def index

  	# to do: Look for next closest city says current city returns nil at points. Gets fixed when you subtract 1 from it ??????????.
  	# Subtracting 1 either means there is an array Index issue or something i forgot just now time to pass out.

	calculator = Calculator.new

	loopCounter = 30
	fieldSize = 1000
	@totalTravelTime = 0
	graph = Array.new(fieldSize) { Array.new(fieldSize, 0)  }
	@cities = Array.new(loopCounter) { [0, 0, 420] }
	@cityTravelTime = Array.new(loopCounter) { Array.new(loopCounter, 0) }

	times = 0 
	while times < loopCounter do
		randomX = rand(fieldSize)
		randomY = rand(fieldSize)
		if graph[randomX][randomY] != 1
			graph[randomX][randomY] = 1
			@cities[times][0] = randomX
			@cities[times][1] = randomY
			times +=1
		elsif graph[randomX][randomY] == 1
			times -=1
		end
	end

	currentCity = 0

	while currentCity < loopCounter do
		puts "Calculating nearest city for city #{currentCity}: "
		puts 

		times = 0
		while times < @cities.length do
			if currentCity != times
				distanceX = (@cities[currentCity][0] - @cities[times][0])
				distanceY = (@cities[currentCity][1] - @cities[times][1])
				distanceX = calculator.toPositive(distanceX) if calculator.isNegative(distanceX) == 1
				distanceY = calculator.toPositive(distanceY) if calculator.isNegative(distanceY) == 1
				@cityTravelTime[currentCity][times] = distanceX + distanceY

				print "City #{currentCity} to City: #{times} "
				print "Distance x: #{distanceX} "
				print "Distance y: #{distanceY} "
				print "Total Distance: #{distanceX + distanceY}"
				puts ""
			end
			times += 1
		end
		currentCity += 1
	end

	
	puts "Draw nearest neighbor"
	currentCity = 0
	# Loop requires 'do' after dont forget
	30.times do
		closestCityCounter = 1
		loop do
			closestCityAttempt = @cityTravelTime[currentCity].min(30)[closestCityCounter]

			print @cities[currentCity][2]
			puts @cityTravelTime[currentCity].index(closestCityAttempt)

			if @cities[@cityTravelTime[currentCity].index(closestCityAttempt)][2] == 420
				@totalTravelTime += closestCityAttempt
				@cities[currentCity][2] = @cityTravelTime[currentCity].index(closestCityAttempt)
				puts "The closest city to city #{currentCity} is city #{@cityTravelTime[currentCity].index(closestCityAttempt)} with a distance of: #{closestCityAttempt}"

				currentCity = @cityTravelTime[currentCity].index(closestCityAttempt)
				break
			end
			puts "break succesfull!"
			closestCityCounter += 1
		end

	end

		
	print @cities
	puts
	puts @totalTravelTime

  end
end
