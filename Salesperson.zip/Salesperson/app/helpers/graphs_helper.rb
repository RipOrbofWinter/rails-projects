module GraphsHelper
end
